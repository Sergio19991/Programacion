package com.sergiobejaranoarroyo;

public interface Encestar {
    public default String correr() {
        return "2 puntos!!!!!";
    }
}