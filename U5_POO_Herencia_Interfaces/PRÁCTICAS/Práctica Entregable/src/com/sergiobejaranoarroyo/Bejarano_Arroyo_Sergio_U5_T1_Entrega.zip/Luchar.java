package com.sergiobejaranoarroyo;

public interface Luchar {
    public default String correr() {
        return "Voy a pelear";
    }
}