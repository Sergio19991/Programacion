package com.sergiobejaranoarroyo;

import com.sergiobejaranoarroyo.Empresa.Departamento;
import com.sergiobejaranoarroyo.Empresa.Empleado;
import com.sergiobejaranoarroyo.Empresa.Empresa;

public class Main {

    public static void main(String[] args) {
        //Empresa empresa = new Empresa("Alixar", {"Sistemas Informáticos", "Lenguaje de Marcas y Sistemas de Gestión de Información"});
        //Departamento departamento1 = new Departamento("Sistemas Informáticos", "+34", "empleado1");
        //Departamento departamento2 = new Departamento("Sistemas Informáticos", "Guillena", "+34","empleado1");
        //Departamento departamento3 = new Departamento("Sistemas Informáticos", "Castilleja de la Cuesta", "+36", "empleado2");
    }
}