package com.sergiobejaranoarroyo;

public class Ejercicio3 {
    public static void main(String[] args) {
        String[] ejeX = {"a", "b", "c", "d", "f", "g", "h"};
        int[] ejeY = {1, 2, 3, 4, 5, 6, 7, 8};
        int[][] tablero = new int[8][8];
    }

    public static boolean jaque(String posRey, String posReina) {
        return false;
    }

}