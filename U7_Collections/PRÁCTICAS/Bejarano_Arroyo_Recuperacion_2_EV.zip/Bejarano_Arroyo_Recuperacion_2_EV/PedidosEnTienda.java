package com.sergiobejaranoarroyo;

public class PedidosEnTienda extends Cliente {
    public PedidosEnTienda(String nombre, String apellidos, String dni, String telefono, String email, String direccionTienda) {
        super(nombre, apellidos, dni, telefono, email, direccionTienda);
    }
}