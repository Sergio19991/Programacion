package com.sergiobejaranoarroyo;

public enum MetodoPago {TARJETA_CREDITO, PAYPAL, STRIPE}